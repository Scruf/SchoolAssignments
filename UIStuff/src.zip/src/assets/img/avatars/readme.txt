All avatars used in the demo are not available for commercial use,
so I couldn't include them in the final package. If you would like
them for mockup purposes, you can either replace the images in this
folder with avatars from http://uifaces.com/ or you can contact me
to send you the ones I've used in the demo (also from uifaces.com).

Thank you! :-)